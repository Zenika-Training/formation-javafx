package com.zenika.fx.zwitter;

public class MainController {

}
